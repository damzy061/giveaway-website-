# Giveaway Website

## Overview
This is a full-featured giveaway website where users can sign up, log in, enter giveaways, purchase gift boxes, and more.

## Features
- User Registration and Login
- Giveaway Entry
- Gift Box Purchase
- On-site Payments
- Advertisements

## Technologies Used
- Frontend: React.js
- Backend: Node.js with Express
- Database: MongoDB

## Setup Instructions

### Prerequisites
- Node.js (v14 or higher)
- MongoDB

### Backend Setup
1. Navigate to the `backend` folder:
    ```sh
    cd backend
    ```
2. Install the dependencies:
    ```sh
    npm install
    ```
3. Create a `config.js` file in the `backend` folder with your MongoDB URI, JWT secret, and payment gateway API key:
    ```javascript
    module.exports = {
        mongoURI: 'your_mongodb_uri',
        jwtSecret: 'your_jwt_secret',
        paymentGatewayAPIKey: 'your_payment_gateway_api_key'
    };
    ```
4. Start the backend server:
    ```sh
    npm start
    ```

### Frontend Setup
1. Navigate to the `frontend` folder:
    ```sh
    cd frontend
    ```
2. Install the dependencies:
    ```sh
    npm install
    ```
3. Start the frontend development server:
    ```sh
    npm start
    ```

### Running the Application
1. Ensure both backend and frontend servers are running.
2. Visit `http://localhost:3000` in your browser to access the website.

## Deployment
Refer to the documentation of your hosting provider for deploying Node.js and React applications.

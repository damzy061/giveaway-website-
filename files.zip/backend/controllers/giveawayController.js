const Giveaway = require('../models/Giveaway');

exports.createGiveaway = async (req, res) => {
    const { title, description, prize, endDate } = req.body;
    try {
        const newGiveaway = new Giveaway({ title, description, prize, endDate });
        await newGiveaway.save();
        res.json(newGiveaway);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
};

exports.getGiveaways = async (req, res) => {
    try {
        const giveaways = await Giveaway.find();
        res.json(giveaways);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
};
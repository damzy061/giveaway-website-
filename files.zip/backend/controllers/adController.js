const Advertisement = require('../models/Advertisement');

exports.getAds = async (req, res) => {
    try {
        const ads = await Advertisement.find();
        res.json(ads);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
};
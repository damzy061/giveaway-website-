const GiftBox = require('../models/GiftBox');
const config = require('../config');

exports.purchaseGiftBox = async (req, res) => {
    const { userId, giftBoxId, paymentDetails } = req.body;
    try {
        // Process payment using payment gateway API
        const paymentResponse = await processPayment(paymentDetails, config.paymentGatewayAPIKey);
        if (paymentResponse.status !== 'success') {
            return res.status(400).json({ msg: 'Payment failed' });
        }

        // Update user's gift box purchase history
        const giftBox = await GiftBox.findById(giftBoxId);
        if (!giftBox) {
            return res.status(400).json({ msg: 'Gift box not found' });
        }

        // Save purchase details in database
        const purchase = { userId, giftBoxId, paymentDetails, date: new Date() };
        await savePurchaseDetails(purchase);

        res.json({ msg: 'Gift box purchased successfully' });
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
};
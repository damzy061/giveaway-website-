module.exports = {
    mongoURI: 'your_mongodb_uri',
    jwtSecret: 'your_jwt_secret',
    paymentGatewayAPIKey: 'your_payment_gateway_api_key'
};
import React from 'react';

function AdminPanel() {
    return (
        <div>
            <h2>Admin Panel</h2>
            <p>Manage giveaways, users, and more.</p>
        </div>
    );
}

export default AdminPanel;
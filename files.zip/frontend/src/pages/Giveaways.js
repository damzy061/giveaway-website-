import React, { useEffect, useState } from 'react';
import axios from 'axios';

function Giveaways() {
    const [giveaways, setGiveaways] = useState([]);

    useEffect(() => {
        const fetchGiveaways = async () => {
            try {
                const res = await axios.get('/api/giveaways');
                setGiveaways(res.data);
            } catch (err) {
                console.error(err.response.data);
            }
        };
        fetchGiveaways();
    }, []);

    return (
        <div>
            <h2>Available Giveaways</h2>
            <ul>
                {giveaways.map((giveaway) => (
                    <li key={giveaway._id}>
                        <h3>{giveaway.title}</h3>
                        <p>{giveaway.description}</p>
                        <p>Prize: {giveaway.prize}</p>
                        <p>End Date: {new Date(giveaway.endDate).toLocaleDateString()}</p>
                    </li>
                ))}
            </ul>
        </div>
    );
}

export default Giveaways;
import React from 'react';

function Home() {
    return (
        <div>
            <h1>Welcome to the Giveaway Website</h1>
            <p>Enter giveaways, buy gift boxes, and more!</p>
        </div>
    );
}

export default Home;
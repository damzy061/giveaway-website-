import React, { useState } from 'react';
import axios from 'axios';

function PurchaseGiftBox() {
    const [giftBoxId, setGiftBoxId] = useState('');
    const [paymentDetails, setPaymentDetails] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const res = await axios.post('/api/payments/purchase-gift-box', { giftBoxId, paymentDetails });
            console.log(res.data);
        } catch (err) {
            console.error(err.response.data);
        }
    };

    return (
        <div>
            <h2>Purchase Gift Box</h2>
            <form onSubmit={handleSubmit}>
                <input type="text" placeholder="Gift Box ID" value={giftBoxId} onChange={(e) => setGiftBoxId(e.target.value)} required />
                <input type="text" placeholder="Payment Details" value={paymentDetails} onChange={(e) => setPaymentDetails(e.target.value)} required />
                <button type="submit">Purchase</button>
            </form>
        </div>
    );
}

export default PurchaseGiftBox;
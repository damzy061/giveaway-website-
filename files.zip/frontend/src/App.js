import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Home from './pages/Home';
import Signup from './pages/Signup';
import Login from './pages/Login';
import Giveaways from './pages/Giveaways';
import PurchaseGiftBox from './pages/PurchaseGiftBox';
import AdminPanel from './pages/AdminPanel';

function App() {
    return (
        <Router>
            <Switch>
                <Route path="/" exact component={Home} />
                <Route path="/signup" component={Signup} />
                <Route path="/login" component={Login} />
                <Route path="/giveaways" component={Giveaways} />
                <Route path="/purchase-gift-box" component={PurchaseGiftBox} />
                <Route path="/admin" component={AdminPanel} />
            </Switch>
        </Router>
    );
}

export default App;